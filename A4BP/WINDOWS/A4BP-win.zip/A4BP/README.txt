Pharo 4.0

This distribution was built May 26, 2015.